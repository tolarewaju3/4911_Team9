For static architecture, see developer/static.png.
For dynamic architecture, see the sequence diagrams in developer/dynamic.
For detailed design documentation, see the comments in our web and android code.
For data storage documentation, see developer/er.pdf.
For user interface documentation, see the pdf files in developer/ui.
For user documentation, see the pdf files in user.